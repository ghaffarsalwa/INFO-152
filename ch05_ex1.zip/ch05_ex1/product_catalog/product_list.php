<!--
 Project Name	  		Enhance the Guitar Shop application
 Date			  	02/1/2020
 Programmer Name		Salwa Ghaffar
 Project Description            Enhance the Product Manager application
-->

<?php include '../view/header.php'; ?>
<div id="main">
    <div id="sidebar">
        <h1>Categories</h1>
        <?php include('../view/sidebar.php'); ?>
    </div>
    <div id="content">
        <h1><?php echo $category_name; ?></h1>
        <ul class="nav">
            <?php foreach ($products as $product) : ?>
            <li>
                <a href="?action=view_product&product_id=
                    <?php echo $product['productID']; ?>">
                    <?php echo $product['productName']; ?>
                </a>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
</div>
<?php include '../view/footer.php'; ?>