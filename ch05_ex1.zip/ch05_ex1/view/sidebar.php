<!--
 Project Name	  		Enhance the Guitar Shop application
 Date			  	02/1/2020
 Programmer Name		Salwa Ghaffar
 Project Description            Enhance the Product Manager application
-->

<div id="sidebar">
    <ul class="nav">
        <!-- display links for all categories -->
        <?php foreach($categories as $category) : ?>
        <li>
            <a href="?category_id=<?php 
                    echo $category['categoryID']; ?>">
              <?php echo $category['categoryName']; ?>
            </a>
        </li>
        <?php endforeach; ?>
    </ul>
</div>