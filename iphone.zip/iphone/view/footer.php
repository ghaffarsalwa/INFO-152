
        </div><!-- end main -->
        <div id="footer">
            <p class="copyright">
                &copy; <?php echo date("Y"); ?> iPhone Shop, Inc.
            </p>
        </div>
    </div><!-- end page -->
    </body>
</html>