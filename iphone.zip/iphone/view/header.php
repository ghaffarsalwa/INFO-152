<html>
    
    <!-- the head section -->
    <head>
        <title>iPhone Shop</title>
        <link rel="stylesheet" type="text/css"
              href="<?php echo $app_path ?>main.css" />
    </head>

    <!-- the body section -->
    <body>
    <div id="page">
        <div id="header">
            <h1>iPhone Shop</h1>
        </div>
        <div id="main">

