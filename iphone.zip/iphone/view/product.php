
<?php
    // Parse data
    $category_id = $iphone['categoryID'];
    $iphone_code = $iphone['iphoneCode'];
    $iphone_name = $iphone['iphoneName'];
    $iphone_color = $iphone['iphoneColor'];
    $iphone_storage = $iphone['iphoneStorage'];
    $description = $iphone['description'];
    $list_price = $iphone['listPrice'];

    // Add HMTL tags to the description
    $description = add_tags($description);
    $iphoneColor = add_tags($iphone_color);
    $iphoneStorage = add_tags($iphone_storage);
    

    // Get image URL and alternate text
    $image_filename = $iphone_code . '.png';
    $image_path = $app_path . '../images/' . $image_filename;
    $image_alt = 'Image filename: ' . $image_filename;
?>

<h1><?php echo $iphone_name; ?></h1>
<div id="left_column">
    <p><img src="<?php echo $image_path; ?>"
            alt="<?php echo $image_alt; ?>"
            width="200"
            height="200"/></p>
</div>

<div id="right_column">
    <p><b>List Price:</b>
        <?php echo '$' . $list_price; ?></p>
    
    <form action="<?php echo $app_path . 'cart' ?>" method="post">
        <input type="hidden" name="action" value="add" />
        <input type="hidden" name="iphone_id"
               value="<?php echo $iphone_id; ?>" />
        <b>Quantity:</b>
        <input type="text" name="quantity" value="1" size="2" />
        <input type="submit" value="Add to Cart" />
    </form>
    <h2>Description</h2>
    <?php echo $description; ?> <br/>
    <?php echo $iphone_color; ?><br/>
    <br/>
    <?php echo $iphone_storage; ?><br/>
</div>