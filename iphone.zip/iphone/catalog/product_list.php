<?php include '../view/header.php'; ?>
<div id="content">
    <h1><?php echo $current_category['categoryName']; ?></h1
    <?php if (count($iphones) == 0) : ?>
        <p>There are no products in this category.</p>
    <?php else: ?>
        <?php foreach ($iphones as $iphone) : ?>
        <p>
            <a href="?action=view_product&amp;iphone_id=<?php
                      echo $iphone['iphoneID']; ?>">
                <?php echo $iphone['iphoneName']; ?>
            </a>
        </p>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
<?php include '../view/footer.php'; ?>