<?php
function get_iphones_by_category($category_id) {
    global $db;
    $query = 'SELECT * FROM iphones
              WHERE categoryID = :category_id
              ORDER BY iphoneID';
    try {
        $statement = $db->prepare($query);
        $statement->bindValue(':category_id', $category_id);
        $statement->execute();
        $result = $statement->fetchAll();
        $statement->closeCursor();
        return $result;
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        display_db_error($error_message);
    }
}

function get_iphones() {
    global $db;
    $query = 'SELECT * FROM iphones ORDER BY iphoneID';
    try {
        $statement = $db->prepare($query);
        $statement->execute();
        $result = $statement->fetchAll();
        $statement->closeCursor();
        return $result;
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        display_db_error($error_message);
    }
}

function get_iphone($iphone_id) {
    global $db;
    $query = 'SELECT *
              FROM iphones
              WHERE iphoneID = :iphone_id';
    try {
        $statement = $db->prepare($query);
        $statement->bindValue(':iphone_id', $iphone_id);
        $statement->execute();
        $result = $statement->fetch();
        $statement->closeCursor();
        return $result;
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        display_db_error($error_message);
    }
}

function add_iphone($category_id, $code, $name, $color, $storage, $description, $price, $discount_percent) {
    global $db;
    $query = 'INSERT INTO iphones
                 (categoryID, iphoneCode, iphoneName, iphoneColor, iphoneStorage, description, listPrice, discountPercent)
                 
              VALUES
                 (:category_id, :code, :name, :color, :storage, :description, :price, :discount_percent)';
    try {
        $statement = $db->prepare($query);
        $statement->bindValue(':category_id', $category_id);
        $statement->bindValue(':code', $code);
        $statement->bindValue(':name', $name);
        $statement->bindValue(':color', $color);
        $statement->bindValue(':storage', $storage);
        $statement->bindValue(':description', $description);
        $statement->bindValue(':price', $price);
        $statement->bindValue(':discount_percent', $discount_percent);
        $statement->execute();
        $statement->closeCursor();

        // Get the last product ID that was automatically generated
        $iphone_id = $db->lastInsertId();
        return $iphone_id;
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        display_db_error($error_message);
    }
}

function update_iphone($iphone_id, $code, $name, $color, $storage, $description,
                        $price, $discount_percent, $category_id) {
    global $db;
    $query = 'UPDATE iphones
              SET iphoneName = :name,
                  iphoneCode = :code,
                  iphoneColor = :color;
                  iphoneStorage = :storage;
                  description = :description,
                  listPrice = :price,
                  discountPercent = :discount_percent,
                  categoryID = :category_id
              WHERE iphoneID = :iphone_id';
    try {
        $statement = $db->prepare($query);
        $statement->bindValue(':name', $name);
        $statement->bindValue(':code', $code);
        $statement->bindValue(':color', $color);
        $statement->bindValue(':storage', $storage);
        $statement->bindValue(':description', $description);
        $statement->bindValue(':price', $price);
        $statement->bindValue(':discount_percent', $discount_percent);
        $statement->bindValue(':category_id', $category_id);
        $statement->bindValue(':iphone_id', $iphone_id);
        $row_count = $statement->execute();
        $statement->closeCursor();
        return $row_count;
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        display_db_error($error_message);
    }
}

function delete_iphone($iphone_id) {
    global $db;
    $query = 'DELETE FROM iphones WHERE iphoneID = :iphone_id';
    try {
        $statement = $db->prepare($query);
        $statement->bindValue(':iphone_id', $iphone_id);
        $row_count = $statement->execute();
        $statement->closeCursor();
        return $row_count;
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        display_db_error($error_message);
    }
}
?>