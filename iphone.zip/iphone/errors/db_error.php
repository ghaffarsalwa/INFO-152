<?php include 'view/header.php'; ?>
<div id="content">
    <h1>Database Error</h1>
    <p>A database error occurred.</p>
    <p>Error message: <?php echo $error_message; ?></p>
    <p>&nbsp;</p>
</div><!-- end content -->
<?php include 'view/footer.php'; ?>