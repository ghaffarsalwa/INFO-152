<?php include 'view/header.php'; ?>
<div id="content">
    <h1>Database Error</h1>
    <p>An error occurred connecting to the database.</p>
    <p>&nbsp;</p>
</div><!-- end content -->
<?php include 'view/footer.php'; ?>