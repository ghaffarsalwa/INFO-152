<?php include 'view/header.php'; ?>
<div class="row">
    <p><br />iPhone Shop is a used iPhones selling site where you can find and buy all iPhones at the cheapest price. </p>

    <!-- display product -->
    <h1>iPhones</h1>
    

    <h2> Categories </h2>
    <?php foreach ($categories as $category) :
        // Get product data
        $categoryName = $category['categoryName'];
        
    ?>
    
        <div id="category_image_row">
            <img src="images/<?php echo $category['categoryName']; ?>.png"
                 alt="&nbsp;" width="190" height="200">
        
            <p>
                <a href="catalog?action=view_category&amp;category_id=<?php 
                          echo $category['categoryID']; ?>">
                    <?php echo $category['categoryName']; ?>
                </a>
            </p>
        </div>
        
    <?php endforeach; ?>
    
</div>

<br />

<div id="content">
    <h2> Products </h2>    
    <table>
    <?php foreach ($iphones as $iphone) :
        // Get product data
        $list_price = $iphone['listPrice'];
        $discount_percent = $iphone['discountPercent'];
        $description = $iphone['description'];
        
    ?>
    <tr>
        <td id="product_image_column">
            <img src="images/<?php echo $iphone['iphoneCode']; ?>.png"
                 alt="&nbsp;" width="190" height="200">
        </td>
        <td>
            <p>
                <a href="catalog?action=view_product&amp;iphone_id=<?php 
                          echo $iphone['iphoneID']; ?>">
                    <?php echo $iphone['iphoneName']; ?>
                </a>
            </p>
                <p>
                    <b>Your price:</b>
                    $<?php echo $list_price; ?>
                </p>
                <p>
                    <?php echo $description; ?>
                </p>
        </td>
    </tr>
    <?php endforeach; ?>
    </table>
</div>
<?php include 'view/footer.php'; ?>