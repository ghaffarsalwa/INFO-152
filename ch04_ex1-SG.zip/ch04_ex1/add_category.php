<!--

 Project Name	  		Enhance the Product Manager application
 Date			  		01/23/2020
 Programmer Name		Salwa Ghaffar
 Project Description	Add a Category Manager page

-- >


<?php
  $categoryName = filter_input (INPUT_POST, 'categoryName');

// Validate inputs S.G.
if ($categoryName == null)  {
    $error = "Invalid category. Please try again.";
    include('error.php');
} else {
    // If valid, add the product to the database S.G.
    require_once('database.php');
	
	
    $query = 'INSERT INTO categories
                 (categoryName)
              VALUES
                 (:categoryName)';
    $statement = $db->prepare($query);
	$statement-> bindValue(':categoryName',  $categoryName);
	$statement-> execute();
	$statement-> closeCursor();
	
	
    // Display the category List page S.G.
    include('category_list.php');
}
?>